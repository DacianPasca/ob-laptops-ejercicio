package com.obspring.obh2jpawebdevtools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObH2JpaWebDevtoolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
