package com.obspring.obh2jpawebdevtools.controller;

import com.obspring.obh2jpawebdevtools.entities.Laptop;
import com.obspring.obh2jpawebdevtools.repository.LaptopRepository;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class LaptopController {

    // 1. Atributos
    private LaptopRepository laptopRepository;

    // 2. Constructores
    public LaptopController(LaptopRepository laptopRepository){
        this.laptopRepository = laptopRepository;
    }

    // CRUD

    /**
     * http://localhost:8080/api/laptops
     * @return
     */
    @GetMapping("/api/laptops")
    public List<Laptop> findAll(){
        // recuperar y devolver los libros de base de datos
        return laptopRepository.findAll();
    }

    // Crear un nuevo laptop en base de datos
    @PostMapping("/api/laptops")
    public Laptop create(@RequestBody Laptop laptop, @RequestHeader HttpHeaders headers){
        return laptopRepository.save(laptop);
    }
}
